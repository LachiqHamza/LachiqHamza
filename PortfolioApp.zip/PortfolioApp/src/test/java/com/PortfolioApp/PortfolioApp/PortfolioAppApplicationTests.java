package com.PortfolioApp.PortfolioApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
