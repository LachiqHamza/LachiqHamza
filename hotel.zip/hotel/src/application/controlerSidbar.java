package application;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class controlerSidbar {
	
	
	@FXML
    private BorderPane bp;
	@FXML
    private AnchorPane ap;
	
	
	
	
	
	@FXML
    private void home(MouseEvent event) {
		
		bp.setCenter(ap);
		
	}
	@FXML
    private void page1(MouseEvent event) {
		
		loadPage("page1");
		
	}
	@FXML
    private void page2(MouseEvent event) {
		
		loadPage("page2");
		
	}
	@FXML
    private void page3(MouseEvent event) {
		
		loadPage("page3");
		
	}
	@FXML
    private void page4(MouseEvent event) {
		loadPage("page4");
		
		
	}
	@FXML
    private void page5(MouseEvent event) {
		
		loadPage("page5");
		
	}
	
	private void loadPage(String page) {
		
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource(page+".fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bp.setCenter(root);
		
	}
	  
	
	

}
